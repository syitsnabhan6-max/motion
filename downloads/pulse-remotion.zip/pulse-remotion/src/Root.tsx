import React from 'react';
import {Composition} from 'remotion';
import {PulseFilm} from './pulse/PulseFilm';
export const Root: React.FC = () => <Composition id="Pulse" component={PulseFilm} width={1080} height={1920} fps={60} durationInFrames={1440}/>;
