import React from 'react';
import {Composition} from 'remotion';
import {ArcherFilm} from './archer/ArcherFilm';
export const Root:React.FC=()=> <Composition id="Archer" component={ArcherFilm} width={1800} height={600} fps={60} durationInFrames={2040}/>;
