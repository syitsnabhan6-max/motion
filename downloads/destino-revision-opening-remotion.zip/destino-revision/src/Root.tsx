import React from 'react';
import {Composition} from 'remotion';
import {DestinoRevision} from './destino/revision/Opening';
export const Root=()=> <Composition id="DestinoRevision" component={DestinoRevision} defaultProps={{audio:true}} width={1080} height={1920} fps={60} durationInFrames={900}/>;
