import React from 'react';
import {Composition} from 'remotion';
import {CupangFilm} from './cupang/CupangFilm';
import {PulseFilm} from './pulse/PulseFilm';
export const Root:React.FC=()=> <>
  <Composition id="Cupang" component={CupangFilm} width={1800} height={600} fps={60} durationInFrames={1440}/>
  <Composition id="Pulse" component={PulseFilm} width={1080} height={1920} fps={60} durationInFrames={1440}/>
</>;
