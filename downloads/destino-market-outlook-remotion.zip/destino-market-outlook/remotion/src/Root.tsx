import React from 'react';
import {Composition} from 'remotion';
import {DestinoFilm} from './destino/DestinoFilm';
import {DestinoCover} from './destino/DestinoCover';
import {defaultOutlook,FORMAT} from './destino/content';
export const Root:React.FC=()=> <>
<Composition id="DestinoOutlook" component={DestinoFilm} defaultProps={defaultOutlook} width={1080} height={1920} fps={60} durationInFrames={FORMAT.seconds*60}/>
<Composition id="DestinoCover" component={DestinoCover} defaultProps={defaultOutlook} width={1080} height={1920} fps={60} durationInFrames={1}/>
</>;
